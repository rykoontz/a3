<?php

class RegisterController extends Controller{

	public $usersObject;

	public function defaultTask(){

		$this->usersObject = new Users();
		$this->set('task', 'add');


	}

	public function add(){

			$this->usersObject = new Users();

			$data = array('first_name'=>$_POST['users_firstname'],'last_name'=>$_POST['users_lastname']),'email'=>$_POST['users_email'],'password'=>$_POST['users_password'];

			$result = $this->usersObject->addUser($data);

			$this->set('message', $result);


	}

	public function edit($uID){

			$this->usersObject = new Users();

			$users = $this->usersObject->getUser($uID);

			$this->set('uID', $users['uID']);
			$this->set('email', $users['email']);
			$this->set('first_name', $users['first_name']);
			$this->set('last_name',$users['last_name']);
			$this->set('user_type',$users['user_type']);
			$this->set('task', 'update');

			//$post = $this->postObject->update();


	}


}
