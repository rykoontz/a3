<?php
define('DEFAULT_VIEW', 'home');//set this to any page to be the default home page
define('BASE_URL', 'http://corsair.cs.iupui.edu:21921/CIT313/FA2017/a3/');

//database info
define('DB_HOST', 'localhost');
define('DB_USER', 'rykoontz');
define('DB_PASS', 'Baseball23');
define('DB_NAME', 'rykoontz_db');
