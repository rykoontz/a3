<?php include('elements/admin_header.php');?>

<div class="container">
	<div class="page-header">
   <h1> The Register View </h1>
  </div>
  <?php if($message){?>
    <div class="alert alert-success">
    <button type="button" class="close" data-dismiss="alert">×</button>
    	<?php echo $message?>
    </div>
  <?php }?>
  <div class="row">
      <div class="span8">
      <form action="<?php echo BASE_URL?>addUsers/<?php echo $task?>" method="post" onsubmit="editor.post()">
        <div>
        <label for "firstname" id="firstnameLabel">*
        First Name:</label>
        <input type="text" name="users_firstname" id="firstname" value = "<?php echo $first_name?>">
        </div>
        </br>
        <div>
        <label for "lastname" id="lastnameLabel">*
        Last Name:</label>
        <input type="text" name="users_lastname" id="lastname" value = "<?php echo $last_name?>">
        </div>
        </br>
        <div>
        <label for "email" id="emailLabel">*
        Email:</label>
        <input type="email" name="users_email" id="email" value = "<?php echo $email?>">
        </div>
        </br>
        <div>
        <label for="password" id="passwordLabel">*
        Password:</label>
        <input type="password" name="users_password" id="password1" value = "<?php echo $password?>">
        </div>
        </br>
        <div>
        <button id="submit" type="submit" class="btn btn-primary" >Submit</button>
        </div>
        </form>

      </div>
    </div>
</div>
>
<?php include('elements/admin_footer.php');?>
